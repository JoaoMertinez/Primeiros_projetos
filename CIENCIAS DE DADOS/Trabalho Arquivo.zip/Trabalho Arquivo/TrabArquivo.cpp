#include<stdio.h>
#include<conio2.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
/*"rb" Abrir um arquivo bin�rio para leitura. O arquivo deve estar presente no disco.

"wb" Abrir um arquivo bin�rio para grava��o. Se o arquivo estiver presente ele ser� 
destru�do e reinicializado. Se n�o existir, ele ser� criado.

"ab" Abrir um arquivo bin�rio para inclus�o. Os dados ser�o adicionados ao fim do arquivo 
existente, ou um novo arquivo ser� criado. N�o permite leitura dos dados.

"rb+" Abrir um arquivo bin�rio para leitura e grava��o. O arquivo deve existir e pode ser 
atualizado.

"wb+" Abrir um arquivo bin�rio para leitura e grava��o. Se o arquivo existir ele ser� 
destru�do e reinicializado. Se n�o existir, ser� criado.

"ab+" Abrir um arquivo bin�rio para atualiza��es e para adicionar dados ao fim do arquivo 
existente ou um novo arquivo ser� criado. Possibilita a leitura dos dados existentes.*/


//Struct com as datas de validade
struct TpValidade
{
	int dia, mes, ano;
};

//Struct com as datas de venda
struct TpData
{
	int dia, mes, ano;
};

//Struct com as informa��es dos produtos
struct TpProdutos
{
	int cod, estoque, codForn;
	char descr[30], status;
	float preco;
	
	TpValidade validade;
};

//Struct com as informa��es dos fornecedores
struct TpFornecedor
{
	int codForn;
	char nomeForn[30], cidade[30],status;
};

//Struct com as informa��es dos clientes
struct TpCliente
{
	int qtdeCompra, cpf;
	char nomeCliente[30], status;
	float valorTotCompr;
	TpData data;
};

//Struct com as informa��es das vendas
struct TpVendas
{
	int codVenda, CPFCLI; //CodVenda tem que ser sequencial
	float totVenda;
	char status;
	TpData data;
	
};

//Struct com as informa��es das vendas dos produtos
struct TpVendaProd
{
	int codProd;
	int codVenda;
	int qtde;
	char status;
	float valorUni;
};

//Fun��o que limpa a tela
void LimpaTela(void)
{
	 int x,y;
	 //LIMPA QUADRADO
	 for(x=30;x<=78;x++)
	 {
		for(y=6;y<=20;y++)
		{
		   gotoxy(x,y);
		   printf(" ");
		}
	 }
	 //LIMPA MENSAGEM
	 for(x=13;x<78;x++)
	 {
	 	gotoxy(x,23);
		printf("  ");
	 }
}

//Fun��o que Limpa Mensagem
void LimpaMensagem(void)
{
	int x,y;
	
	for(x=13;x<78;x++)
	 {
	 	gotoxy(x,23);
		printf("  ");
	 }
}


void moldura(int CI, int LI, int CF, int LF, int CorT, int CorF)
{
	int i;
	textcolor(12);
	textbackground(3);
	gotoxy(CI,LI);
	printf("%c",201);
	gotoxy(CI,LF);
	printf("%c",200);
	gotoxy(CF,LI);
	printf("%c",187);
	gotoxy(CF,LF);
	printf("%c",188);
	for(i=CI+1; i<CF; i++)
	{
		gotoxy(i,LI); printf("%c",205);
		gotoxy(i,LF); printf("%c",205);
	}
	for(i=LI+1; i<LF; i++)
	{
		gotoxy(CI,i); printf("%c",186);
		gotoxy(CF,i); printf("%c",186);
	}
	
	textcolor(7);
	textbackground(0);
}

//Fun��o com o menu principal
void menuPrincipal(void)
{
	textcolor(15);
	gotoxy(3,7);
	printf("# #  M E N U  # #");
	gotoxy(3,9);
	printf("[P] Produtos");
	gotoxy(3,10);
	printf("[C] Clientes");
	gotoxy(3,11);
	printf("[F] Fornecedores");
	gotoxy(3,19);
	printf("[ESC] Sair");
}

//Fun��o que passa os valores da moldura
void Formulario(void)
{
	system("cls");
	moldura(1,1,80,25,10,5);
	gotoxy(27,3);
	textcolor(15);
	printf(" # # #  MERCADO DO LUDIMILO  # # #");
	
	moldura(2,2,79,4,14,1);
	moldura(2,5,27,21,12,7);
	menuPrincipal();
	moldura(2,22,79,24,11,4);
	gotoxy(4,23);
	textcolor(12);
	printf("Mensagem: ");

	moldura(28,5,79,21,9,6);
}

//Fun��o do menu de op��o para o usuario escolher (PRODUTOS)
char menuProd(void)
{
	char i;
	LimpaTela();
	gotoxy(30,6);
	printf("# # #  M E N U  P R O D U T O S  # # #\n");
	gotoxy(30,8);
	printf("[A] Cadastrar Produtos");
	gotoxy(30,9);
	printf("[B] Consultar Produtos");
	gotoxy(30,10);
	printf("[C] Excluir Produtos");
	gotoxy(30,11);
	printf("[D] Alteracao de dados");
	gotoxy(30,12);
	printf("[E] Relatorio de Produtos");
	gotoxy(30,13);
	printf("[F] Relatorio de vendas");
	gotoxy(30,14);
	printf("[G] Vender Produtos");
	gotoxy(30,15);
	printf("[I] Exclusao de Vendas");
	gotoxy(30,16);
	printf("[0] Sair\n");
	gotoxy(30,18);
	printf("Opcao desejada: ");
	return toupper(getch());
}

//Fun��o do menu de op��o para o usuario escolher (CLIENTES)
char menuCliente(void)
{
	LimpaTela();
	gotoxy(30,6);
	printf("# # #  M E N U  C L I E N T E S  # # #\n");
	gotoxy(30,8);
	printf("[A] Cadastrar Cliente");
	gotoxy(30,9);
	printf("[B] Consultar Cliente pelo cpf");
	gotoxy(30,10);
	printf("[C] Excluir cliente");
	gotoxy(30,11);
	printf("[D] Alteracao de Dados");
	gotoxy(30,12);
	printf("[E] Relatorio de clientes");
	gotoxy(30,13);
	printf("[0] Sair\n");
	gotoxy(30,15);
	printf("Opcao desejada: ");
	return toupper(getche());
}

//Fun�ao do menu de fornecedor
char menuForn(void)
{
	LimpaTela();
	gotoxy(30,6);
	printf("# # #  M E N U  F O R N E C E D O R  # # #\n");
	gotoxy(30,8);
	printf("[A] Cadastrar novo fornecedor");
	gotoxy(30,9);
	printf("[B] Consultar Fornecedores");
	gotoxy(30,10);
	printf("[C] Excluir fornecedores");
	gotoxy(30,11);
	printf("[D] Alteracao de Dados");
	gotoxy(30,12);
	printf("[E] Aumento de preco por fornecedor");
	gotoxy(30,13);
	printf("[F] Relatorio de dados");
	gotoxy(30,14);
	printf("[0] Sair\n");
	gotoxy(30,16);
	printf("Opcao desejada: ");
	return toupper(getche());
	
}
//Fun��o que faz a busca do c�digo do fornecedor em arquivo
int BuscaForn(FILE *ptr, int cod)
{
	TpFornecedor forn;
	rewind(ptr);
	fread(&forn,sizeof(TpFornecedor),1,ptr);
	
	while(!feof(ptr) && !(cod == forn.codForn && forn.status == 'A'))
		fread(&forn,sizeof(TpFornecedor),1,ptr);
	
	if(!feof(ptr) && forn.status == 'A')
		return ftell(ptr)-sizeof(TpFornecedor);
	else
		return -1;	
}

//fun��o que faz a busca do fornecedor na tabela de produtos
int buscaProdforn(FILE *Ptr, int codForn)
{
	TpProdutos prod;
	rewind(Ptr);
	fread(&prod,sizeof(TpProdutos),1,Ptr);
	
	while(!feof(Ptr) && !(codForn == prod.codForn && prod.status == 'A'))
		fread(&prod,sizeof(TpProdutos),1,Ptr);
		
	if(!feof(Ptr) && prod.status == 'A')
		return ftell(Ptr) - sizeof(TpProdutos);
	else
		return -1;
}

int buscaPfAumt(FILE *Ptr, int codForn)
{
	TpProdutos prod;
	fread(&prod,sizeof(TpProdutos),1,Ptr);
	
	while(!feof(Ptr) && !(codForn == prod.codForn && prod.status == 'A'))
		fread(&prod,sizeof(TpProdutos),1,Ptr);
		
	if(!feof(Ptr) && prod.status == 'A')
		return ftell(Ptr) - sizeof(TpProdutos);
	else
		return -1;
}

//Fun��o que faz a busca do cpf do cliente
int buscaCli(FILE *Ptr, int cpf)
{
	TpCliente cli;
	rewind(Ptr);
	fread(&cli,sizeof(TpCliente),1,Ptr);
	
	while(!feof(Ptr) && !(cpf == cli.cpf && cli.status == 'A'))
		fread(&cli,sizeof(TpCliente),1,Ptr);
		
		
	if(!feof(Ptr) && cli.status == 'A')
		return ftell(Ptr) - sizeof(TpCliente);
	else
		return -1;
}

int buscaCliV(FILE *Ptr, int cpf)//Funcao que faz a busca do cliente na tabela de busca
{
	TpVendas venda;
	rewind(Ptr);
	fread(&venda,sizeof(TpVendas),1,Ptr);
	
	while(!feof(Ptr) && !(cpf == venda.CPFCLI && venda.status == 'A'))
		fread(&venda,sizeof(TpVendas),1,Ptr);
		
		
	if(!feof(Ptr) && venda.status == 'A')
		return ftell(Ptr) - sizeof(TpVendas);
	else
		return -1;
}

//Fun��o que faz busca com sentinela em arquivo
/*
int buscaCliCad(FILE *ptr,int cpf)
{
	TpCliente cli;
	
	fseek(ptr,0,2);//joga pro final
	cli.cpf = cpf;
	fwrite(&cli,sizeof(TpCliente),1,ptr);
	
	rewind(ptr);
	fread(&cli,sizeof(TpCliente),1,ptr);
	while(!feof(ptr) && cpf != cli.cpf )
		fread(&cli,sizeof(TpCliente),1,ptr);
		
	if(!feof(ptr))
		return ftell(ptr)-sizeof(TpCliente);
	else
		return -1;
}
*/

int buscaCliCad(FILE *Ptr,int cpf)
{
	TpCliente cli;
	rewind(Ptr);
	
	fread(&cli,sizeof(TpCliente),1,Ptr);
	
	while(!feof(Ptr) && cpf != cli.cpf)
		fread(&cli,sizeof(TpCliente),1,Ptr);
		
	if(!feof(Ptr) && cli.status == 'A')
		return ftell(Ptr) - sizeof(TpCliente);
	else
		return -1;
	
}

//Fun��o que faz cadastro de cliente em arquivo
void cadCliente(void)
{
	int pos;
	
	LimpaTela();
	
	TpCliente cli;
	FILE *Ptr = fopen("cliente.dat","ab+");
	
	gotoxy(30,6);
	printf("*** Cadastro Cliente ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
		LimpaMensagem();
	}
	else
	{
		gotoxy(30,8);
		printf("Cpf do cliente: ");
		scanf("%d",&cli.cpf);
		
		while(cli.cpf > 0)
		{
			pos = buscaCli(Ptr,cli.cpf);
			
			if(pos == -1)
			{
					gotoxy(30,9);
					printf("Nome do cliente: ");
					fflush(stdin);
					gets(cli.nomeCliente);
					cli.status = 'A';
					
					fseek(Ptr,pos,SEEK_SET);
					fwrite(&cli,sizeof(TpCliente),1,Ptr);
						
					LimpaMensagem();
					gotoxy(13,23);
					printf("Cliente cadastrado com sucesso!");	

			}
			else
			{
				gotoxy(13,23);
				printf("Cpf ja cadastrado!");
			}
			getch();
			LimpaTela();
			gotoxy(30,6);
			printf("*** Cadastro Cliente ***");
			gotoxy(30,8);
			printf("Cpf do cliente: ");
			scanf("%d",&cli.cpf);
		}
		if(cli.cpf == 0)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("CPf invalido!");
		}
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz consulta de um cliente
void ConsultaCliente(void)
{
	int pos;
	TpCliente cli;
	
	FILE *Ptr = fopen("cliente.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Consulta De Cliente ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Digite o cpf para consulta: ");
		scanf("%d",&cli.cpf);
		
		pos = buscaCli(Ptr,cli.cpf);
		fseek(Ptr,pos,SEEK_SET); //SEEK_SET = 0
		fread(&cli,sizeof(TpCliente),1,Ptr);
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("Cliente nao foi encontrado!");
		}
		else
		{	
			
			
			if(cli.status == 'A')
			{
				gotoxy(30,10);
				printf("*** DADOS DO CLIENTE ***");
				gotoxy(30,11);
				printf("status: %c",cli.status);
				gotoxy(30,12);
				printf("Cpf: %d",cli.cpf);
				gotoxy(30,13);
				printf("Nome: %s",cli.nomeCliente);
				/*
				gotoxy(30,14);
				printf("Quantidade total comprada: %d",cli.qtdeCompra);
				gotoxy(30,15);
				printf("Valor total comprado: %.2f",cli.valorTotCompr);
				*/
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Consulta finalizada!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Cliente nao encontrado!!!");
			}
			
		}
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz exclus�o de determinado cliente em arquivo
void excCliente(void)
{
	int pos, auxCpf;
	TpCliente cli;
	
	FILE *Ptr = fopen("cliente.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Exclusao Logica De Cliente ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Digite o cpf para exclusao: ");
		scanf("%d",&auxCpf);
		
		if(auxCpf > 0)
		{
			pos = buscaCli(Ptr,auxCpf);
			
			if(pos == -1)
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Cliente nao foi encontrado!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Cliente encontrado!");
				
				fseek(Ptr,pos,SEEK_SET); //levando o ponteiro para posi��o que achamos
				fread(&cli,sizeof(TpCliente),1,Ptr);
				gotoxy(30,10);
				printf("*** DADOS DO CLIENTE ***");
				gotoxy(30,11);
				printf("Cpf: %d",cli.cpf);
				gotoxy(30,12);
				printf("Nome: %s",cli.nomeCliente);
				/*
				gotoxy(30,13);
				printf("Quantidade total comprada: %d",cli.qtdeCompra);
				gotoxy(30,14);
				printf("Valor total comprado: %.2f",cli.valorTotCompr);
				*/
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Deseja finalizar a exlusao?(S/N) ");
				
				if(toupper(getch()) == 'S')
				{
					cli.status = 'I';
					
					fseek(Ptr,pos,SEEK_SET);
					fwrite(&cli,sizeof(TpCliente),1,Ptr);
					
					LimpaMensagem();
					gotoxy(13,23);
					printf("Exlusao logica finalizada!");
				}
				else
				{
					LimpaMensagem();
					gotoxy(13,23);
					printf("Voce nao autorizou a exclusao!");
				}
			}
		}
		else
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("Cpf invalido!");
		}
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz altera��o de dados do cliente
void alteraCliente(void)
{
	int pos;
	TpCliente cli;
	FILE *Ptr = fopen("cliente.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Alteracao De Dados Do Cliente ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Cpf do cliente: ");
		scanf("%d",&cli.cpf);
		
		pos = buscaCli(Ptr,cli.cpf);
		
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("O cliente nao foi encontrado!");
		}
		else
		{
			fseek(Ptr,pos,SEEK_SET);
			fread(&cli,sizeof(TpCliente),1,Ptr);
			gotoxy(30,10);
			printf("*** DADOS DO CLIENTE ***");
			gotoxy(30,11);
			printf("Cpf: %d",cli.cpf);
			gotoxy(30,12);
			printf("Nome: %s",cli.nomeCliente);
			
			LimpaMensagem();
			gotoxy(13,23);
			printf("Deseja alterar os dados?(S/N)");
			if(toupper(getch()) == 'S')
			{
				gotoxy(30,14);
				printf("Digite o novo nome do cliente: ");
				gotoxy(30,15);
				fflush(stdin);
				gets(cli.nomeCliente);
				
				fseek(Ptr,pos,SEEK_SET);
				fwrite(&cli,sizeof(TpCliente),1,Ptr);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Alteracao de cliente feita com sucesso!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Voce nao autorizou a alteracao de dados!");
			}
		}
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz relatorio dos clientes
void relatorioCliente(void)
{
	int i=8,pos;
	TpCliente cli;
	FILE *Ptr = fopen("cliente.dat","rb");
	FILE *Ptrv = fopen("vendas.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Relatorio De Clientes ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}	
	else
	{
		fread(&cli,sizeof(TpCliente),1,Ptr);
		while(!feof(Ptr))
		{
			pos = buscaCliV(Ptrv,cli.cpf);
			fseek(Ptrv,pos,0);
			if(cli.status == 'A')
			{
				gotoxy(30,i);
				printf("CPF: %d",cli.cpf);
				i++;
				gotoxy(30,i);
				printf("Nome: %s",cli.nomeCliente);
				i++;
				gotoxy(30,i);
				printf("status: %c",cli.status);
				i++;
				
				if(pos == -1)
				{
					gotoxy(30,i);
					printf("Quantidade total comprado: 0");
					i++;
					gotoxy(30,i);
					printf("Valor total comprado: 0");
					i++;
				}
				else
				{
					gotoxy(30,i);
					printf("Quantidade total comprado: %d",cli.qtdeCompra);
					i++;
					gotoxy(30,i);
					printf("Valor total comprado: %.2f",cli.valorTotCompr);
					i++;
				}
				
				//i = i + 2;
				gotoxy(30,i);
				printf("---------------------------------------");
				i = i + 2;
				
				if(i>=18)
				{
					LimpaMensagem();
					gotoxy(13,23);
					printf("Aperte enter para aparecer o restante do relatorio");
					getch();
					LimpaTela();
					gotoxy(30,6);
					printf("*** Relatorio de Clientes ***");
					i=8;
				}
			}
			fread(&cli,sizeof(TpCliente),1,Ptr);
		}
		LimpaMensagem();
		gotoxy(13,23);
		printf("Relatorio finalizado!");
		fclose(Ptr);
		fclose(Ptrv);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz a busca pelo codigo do produto
int buscaProd(FILE *Ptr, int cod)
{
	TpProdutos prod;
	rewind(Ptr);
	fread(&prod,sizeof(TpProdutos),1,Ptr);
	
	while(!feof(Ptr) && !(cod == prod.cod && prod.status == 'A'))
		fread(&prod,sizeof(TpProdutos),1,Ptr);
		
	if(!feof(Ptr) && prod.status == 'A')
		return ftell(Ptr) - sizeof(TpProdutos);
	else
		return -1;
}

//Fun��o que faz cadastro de produtos em arquivo binario
void cadProd(void)
{
	int pos,pos2;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","ab+");
	FILE *Ptrf = fopen("fornecedor.dat","rb");//tem que abrir o arquivo de fornecedor pra fazer a busca
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Cadastro De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo do produto: ");
		scanf("%d",&prod.cod);
		
		while(prod.cod > 0)
		{
			pos = buscaProd(Ptr,prod.cod);
			
			if(pos == -1)
			{	
				gotoxy(30,9);
				printf("Descricao do Produto: ");
				fflush(stdin);
				gets(prod.descr);
				gotoxy(30,10);
				printf("Quantidade em Estoque: ");
				scanf("%d",&prod.estoque);
				gotoxy(30,11);
				printf("Preco: ");
				scanf("%f",&prod.preco);
				gotoxy(30,12);
				printf("Data de Validade dd/mm/aa: ");
				scanf("%d",&prod.validade.dia);
				gotoxy(30,13);
				scanf("%d",&prod.validade.mes);
				gotoxy(30,14);
				scanf("%d",&prod.validade.ano);
				gotoxy(30,15);
				printf("Digite o codigo do fornecedor: ");
				scanf("%d",&prod.codForn);
				prod.status = 'A';
				pos2 = BuscaForn(Ptrf,prod.codForn);
				if(pos2 == -1)
				{
					LimpaTela();
					gotoxy(13,23);
					printf("Fornecedor nao encontrado");
				}
				else
				{
					fseek(Ptr,pos,0);
					fwrite(&prod,sizeof(TpProdutos),1,Ptr);	
					
					LimpaMensagem();
					gotoxy(13,23);
					printf("Produto cadastrado com sucesso!");
				}			
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Produto ja cadastrado!");
			}
			getch();
			LimpaTela();
			gotoxy(30,6);
			printf("*** Cadastro De Produtos ***");
			gotoxy(30,8);
			printf("Digite o codigo do produto: ");
			scanf("%d",&prod.cod);
		}
		if(prod.cod == 0)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("Codigo invalido!");
		}
		fclose(Ptr);
		fclose(Ptrf);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz consulta de produtos em arquivo binario
void ConsultaProd(void)
{
	int pos;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Consulta De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Digite o codigo do produto: ");
		scanf("%d",&prod.cod);
		
		pos = buscaProd(Ptr,prod.cod);
		
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("O produto nao foi encontrado!");
		}
		else
		{
			fseek(Ptr,pos,SEEK_SET);
			fread(&prod,sizeof(TpProdutos),1,Ptr);
			if(prod.status == 'A')
			{
				gotoxy(30,10);
				printf("*** DADOS DO PRODUTO ***");	
			
				gotoxy(30,11);
				printf("Codigo produto: %d",prod.cod);
				gotoxy(30,12);
				printf("Codigo fornecedor: %d",prod.codForn);
				gotoxy(30,13);
				printf("Descricao: %s",prod.descr);
				gotoxy(30,14);
				printf("Estoque: %d",prod.estoque);
				gotoxy(30,15);
				printf("Preco: %.2f",prod.preco);
				gotoxy(30,16);
				printf("Validade: %d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Consulta finalizada!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("O produto nao foi encontrado!");
			}
			
		}
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz exclus�o logica do arquivo de produtos
void excProd(void)
{
	int pos;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Exclusao Logica De Produto ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo do produto: ");
		scanf("%d",&prod.cod);
		
		pos = buscaProd(Ptr,prod.cod);
		
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("O produto nao foi encontrado!");
		}
		else
		{	
			gotoxy(30,10);
			printf("*** DADOS DO PRODUTO ***");	
			
			fseek(Ptr,pos,SEEK_SET);
			fread(&prod,sizeof(TpProdutos),1,Ptr);
			gotoxy(30,11);
			printf("Codigo produto: %d",prod.cod);
			gotoxy(30,12);
			printf("Codigo fornecedor: %d",prod.codForn);
			gotoxy(30,13);
			printf("Descricao: %s",prod.descr);
			gotoxy(30,14);
			printf("Estoque: %d",prod.estoque);
			gotoxy(30,15);
			printf("Preco: %.2f",prod.preco);
			gotoxy(30,16);
			printf("Validade: %d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
			
			LimpaMensagem();
			gotoxy(13,23);
			printf("Deseja finalizar a exlusao?(S/N) ");
			
			if(toupper(getch()) == 'S')
			{
				prod.status = 'I';
				
				fseek(Ptr,pos,SEEK_SET);
				fwrite(&prod,sizeof(TpProdutos),1,Ptr);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Exlusao logica finalizada!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Voce nao autorizou a exclusao!");
			}
			
		}
		
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz altera��o de produtos em arquivo binario
void alteraProd(void)
{
	int pos;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Alteracao De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo do produto: ");
		scanf("%d",&prod.cod);
		
		pos = buscaProd(Ptr,prod.cod);
		
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("O produto nao foi encontrado!");
		}
		else
		{
			gotoxy(30,10);
			printf("*** DADOS DO PRODUTO ***");	
			
			fseek(Ptr,pos,SEEK_SET);
			fread(&prod,sizeof(TpProdutos),1,Ptr);
			gotoxy(30,11);
			printf("Codigo produto: %d",prod.cod);
			gotoxy(30,12);
			printf("Codigo fornecedor: %d",prod.codForn);
			gotoxy(30,13);
			printf("Descricao: %s",prod.descr);
			gotoxy(30,14);
			printf("Estoque: %d",prod.estoque);
			gotoxy(30,15);
			printf("Preco: %.2f",prod.preco);
			gotoxy(30,16);
			printf("Validade: %d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
			
			LimpaMensagem();
			gotoxy(13,23);
			printf("Deseja finalizar a alteracao?(S/N) ");
			
			if(toupper(getch()) == 'S')
			{
				LimpaTela();
				gotoxy(30,6);
				printf("*** Alteracao De Produtos ***");
				
				gotoxy(30,8);
				printf("Nova descricao: ");
				fflush(stdin);
				gets(prod.descr);
				gotoxy(30,9);
				printf("Novo estoque: ");
				scanf("%d",&prod.estoque);
				gotoxy(30,10);
				printf("Novo preco: ");
				scanf("%f",&prod.preco);
				gotoxy(30,11);
				printf("Nova validade: ");
				scanf("%d",&prod.validade.dia);
				gotoxy(30,12);
				scanf("%d",&prod.validade.mes);
				gotoxy(30,13);
				scanf("%d",&prod.validade.ano);
				
				fseek(Ptr,pos,SEEK_SET);
				fwrite(&prod,sizeof(TpProdutos),1,Ptr);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Alteracao de produto feita com sucesso!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Voce nao autorizou a alteracao de dados!");
			}
		}
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz o aumento de preco do produto atraves do fornecedor
void aumentaForn(void)
{
	int pos, porc;
	TpFornecedor forn;
	TpProdutos prod;
	
	FILE *ptra = fopen("produto.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Aumenta o preco por fornecedor ***");
	
	if(ptra == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo do fornecedor para aumento: ");
		scanf("%d",&forn.codForn);
		
		pos = buscaProdforn(ptra,forn.codForn);
		
		if(pos == -1)
		{
			gotoxy(13,23);
			printf("Fornecedor nao cadastrado!");
		}
		else
		{
			gotoxy(30,9);
			printf("Digite a porcentagem para aumento: ");
			scanf("%d",&porc);
			
			
			fseek(ptra,pos,SEEK_SET);
			do
			{
				fread(&prod,sizeof(TpProdutos),1,ptra);
			 	if(prod.codForn == forn.codForn)
				{
					pos = ftell(ptra) - sizeof(TpProdutos);
					
					
					gotoxy(30,11);
					printf("Codigo do produto: %d",prod.cod);
					gotoxy(30,12);
					printf("Preco atual do produto: %.2f",prod.preco);
					
					LimpaMensagem();
					gotoxy(13,23);
					printf("Voce deseja alterar o preco?(S/N)");
					if(toupper(getch()) == 'S')
					{
						prod.preco = prod.preco * porc / 100 + prod.preco;
						
						gotoxy(30,13);
						printf("Preco apos o aumento: %.2f",prod.preco);
						
						fseek(ptra,pos,SEEK_SET);
						fwrite(&prod,sizeof(TpProdutos),1,ptra);
						
						LimpaMensagem();
						gotoxy(13,23);
						printf("Preco atualizado com sucesso!");
						
						getch();
						LimpaTela();
						gotoxy(30,6);
						printf("*** Aumenta o preco por fornecedor ***");
					}
					else
					{
						LimpaMensagem();
						gotoxy(13,23);
						printf("Voce nao autorizou a altera!");
					}
				}
			}while(!feof(ptra));
		}
	
		fclose(ptra);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz relatorio de produtos em arquivo binario
void relatorioProd(void)
{
	int i=8, pos;
	TpProdutos prod;
	TpFornecedor forn;
	FILE *Ptr = fopen ("produto.dat","rb");
	FILE *Ptrf = fopen("fornecedor.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Relatorio De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		fread(&prod,sizeof(TpProdutos),1,Ptr);
		while(!feof(Ptr))
		{
			if(prod.status == 'A')
			{
				pos = BuscaForn(Ptrf,prod.codForn);
				
				fseek(Ptrf,pos,SEEK_SET);
				fread(&forn,sizeof(TpFornecedor),1,Ptrf);
				
				gotoxy(30,i);
				printf("Codigo produto: %d",prod.cod);
				i++;
				gotoxy(30,i);
				printf("Descricao fornecedor: %s",forn.nomeForn);
				i++;
				gotoxy(30,i);
				printf("Descricao: %s",prod.descr);
				i++;
				gotoxy(30,i);
				printf("Estoque: %d",prod.estoque);
				i++;
				gotoxy(30,i);
				printf("Preco: %.2f",prod.preco);
				i++;
				gotoxy(30,i);
				printf("Validade: %d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
				
				i = i + 2;
				
				if(i>=20)
				{
					LimpaMensagem();
					gotoxy(13,23);
					printf("Aperte enter para aparecer o restante do relatorio");
					getch();
					LimpaTela();
					gotoxy(30,6);
					printf("*** Relatorio De Produtos ***");
					i=8;
				}	
			}
			fread(&prod,sizeof(TpProdutos),1,Ptr);
		}
		LimpaMensagem();
		gotoxy(13,23);
		printf("Relatorio finalizado!");
		
		fclose(Ptr);
		fclose(Ptrf);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz cadastro de fornecedor em arquivo
void cadForn(void)
{
	int pos;
	TpFornecedor forn;
	FILE *PtrArq = fopen("fornecedor.dat","ab+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Cadastro De Fornecedor ***");
	
	if(PtrArq == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo de fornecedor: ");
		scanf("%d",&forn.codForn);
		while(forn.codForn > 0)
		{
			pos = BuscaForn(PtrArq,forn.codForn);
			if(pos==-1)
			{
				gotoxy(30,9);
				printf("Nome do fornecedor: ");
				fflush(stdin);
				gets(forn.nomeForn);
				gotoxy(30,10);
				printf("Cidade do fornecedor: ");
				fflush(stdin);
				gets(forn.cidade);
				forn.status = 'A';
				
				fseek(PtrArq,pos,SEEK_SET); // SEEK_SET = 0
				fwrite(&forn,sizeof(TpFornecedor),1,PtrArq);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Fornecedor cadastrado com sucesso!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Codigo ja Cadastrado!");
			}
			getch();
			LimpaTela();
			gotoxy(30,6);
			printf("** Cadastro de Fornecedor **");
			gotoxy(30,8);
			printf("Codigo de fornecedor: ");
			scanf("%d",&forn.codForn);	
		}
		if(forn.codForn == 0)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("Codigo invalido!");
		}
		fclose(PtrArq);		
	}
	getch();
	LimpaTela();
}

//Fun��o que faz consulta de apenas um fornecedor por vez em arquivo binario
void consultaForn(void)
{
	int pos;
	TpFornecedor forn;
	FILE *PtrArq = fopen("fornecedor.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Consulta De Forncedor ***");
	
	if(PtrArq == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{	
		gotoxy(30,8);
		printf("Digite o codigo para consulta: ");
		scanf("%d",&forn.codForn);
		
		pos = BuscaForn(PtrArq,forn.codForn);
		fseek(PtrArq,pos,SEEK_SET); //joga a partir do come�o do arquivo o numero de bits de pos
		fread(&forn,sizeof(TpFornecedor),1,PtrArq);
		
		if(pos == -1)
		{
			LimpaMensagem(); 
			gotoxy(13,23);
			printf("Codigo nao foi encontrado!");
		}
		else
		{
			if(forn.status == 'A')
			{
				gotoxy(30,10);
				printf("*** DADOS DO FORNECEDOR ***");
				gotoxy(30,11);
				printf("Codigo do fornecedor: %d",forn.codForn);
				gotoxy(30,12);
				printf("Nome do fornecedor: %s",forn.nomeForn);
				gotoxy(30,13);
				printf("Cidade do fornecedor: %s",forn.cidade);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Consulta finalizada!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Fornecedor nao foi encontrado!");
			}
		}
		fclose(PtrArq);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz exlusao logica de fornecedor em arquivo binario
void excForn(void)
{
	int pos;
	TpFornecedor forn;
	FILE * ptr = fopen("fornecedor.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Exclusao Logica De Fornecedor ***");
	
	if(ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo para exclusao: ");
		scanf("%d",&forn.codForn);
		
		if(forn.codForn > 0)
		{
			pos=BuscaForn(ptr,forn.codForn);
			
			if(pos == -1)//nao achou
			{
				LimpaMensagem(); 
				gotoxy(13,23);
				printf("Fornecedor nao cadastrado!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Fornecedor encontrado!");
				
				fseek(ptr,pos,SEEK_SET);
				fread(&forn,sizeof(TpFornecedor),1,ptr);//Joga pra frente
				
				gotoxy(30,10);
				printf("*** DADOS DO FORNECEDOR ***");
				gotoxy(30,11);
				printf("Codigo: %d",forn.codForn);
				gotoxy(30,12);
				printf("Nome: %s",forn.nomeForn);
				gotoxy(30,13);
				printf("cidade: %s",forn.cidade);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Deseja finalizar a exlusao?(S/N) ");
				
				if(toupper(getche())=='S')
				{
					forn.status = 'I';
					
					fseek(ptr,pos,SEEK_SET);
					fwrite(&forn,sizeof(TpFornecedor),1,ptr);
					
					LimpaMensagem();
					gotoxy(13,23);
					printf("Exlusao logica finalizada!");
				}
				else
				{
					LimpaMensagem();
					gotoxy(13,23);
					printf("Voce nao autorizou a exclusao!");
				}
		
			}	
		}
		else
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("Codigo invalido!");
		}
		
		fclose(ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz altera��o de dados do forncedor em arquivo binario
void alteraForn(void)
{
	int pos;
	TpFornecedor forn;
	FILE *PtrArq = fopen("fornecedor.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Alteracao De Dados Do Fornecedor ***");
	
	if(PtrArq == NULL)
	{
		gotoxy(30,6);
		printf("Erro na abertura do arquivo!");
	}
	else
	{	
		gotoxy(30,8);
		printf("Digite o codigo para alterar: ");
		scanf("%d",&forn.codForn);
		
		pos = BuscaForn(PtrArq,forn.codForn);
		
		if(pos == -1)//nao achou
    	{
	        LimpaMensagem(); 
	        gotoxy(13,23);
	        printf("Fornecedor nao encontrado!");
    	}
    	else
    	{
    		fseek(PtrArq,pos,SEEK_SET);
        	fread(&forn,sizeof(TpFornecedor),1,PtrArq);
        	
        	gotoxy(30,10);
        	printf("*** DADOS DO FORNECEDOR ***");
        	gotoxy(30,11);
        	printf("Codigo do fornecedor(nao alteravel): %d",forn.codForn);
        	gotoxy(30,12);
			printf("Nome do fornecedor: %s",forn.nomeForn);
			gotoxy(30,13);
			printf("Cidade do fornecedor: %s",forn.cidade);
			
			LimpaMensagem();
			gotoxy(13,23); 
			printf("Deseja alterar os dados?(S/N)");
			if(toupper(getche())=='S')
			{
				gotoxy(30,15);
				printf("Digite o novo nome do fornecedor: ");
				fflush(stdin);
				gets(forn.nomeForn);
				gotoxy(30,16);
				printf("Digite a nova cidade do fornecedor: ");
				fflush(stdin);
				gets(forn.cidade);
				
				fseek(PtrArq,pos,0);
				fwrite(&forn,sizeof(TpFornecedor),1,PtrArq);
				
				LimpaMensagem(); 
		        gotoxy(13,23);
		        printf("Alteracao de fornecedor feita com sucesso!");	
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Voce nao autorizou a alteracao de dados!");
			}	
		}
		fclose(PtrArq);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz relatorio de fornecedor em arquivo binario
void relatorioForn(void)//errado talvez
{
	int pos, i=9;
	TpFornecedor forn;
	FILE *PtrArq = fopen("fornecedor.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Relatorio De Fornecedor ***");
	
	if(PtrArq == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		fread(&forn,sizeof(TpFornecedor),1,PtrArq);
		while(!feof(PtrArq))
		{     
			if(forn.status == 'A')
			{
				gotoxy(30,8);
				printf("CODIGO");
				gotoxy(30,i);
				printf("%d",forn.codForn);
				gotoxy(43,8);
				printf("NOME");
				gotoxy(43,i);
				puts(forn.nomeForn);
				gotoxy(56,8);
				printf("CIDADE");
				gotoxy(56,i);
				puts(forn.cidade);
				i = i + 2;
				if(i==20)
				{
					LimpaMensagem();
				    gotoxy(13,23);
					printf("Aperte enter para aparecer o restante do relatorio");
					getch();
					LimpaTela();
					gotoxy(30,6);
					printf("*** Relatorio De Fornecedor ***");
					i=9;
				}
			}
			fread(&forn,sizeof(TpFornecedor),1,PtrArq);
		}
		LimpaMensagem();
		gotoxy(13,23);
		printf("Relatorio finalizado!");
		fclose(PtrArq);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz busca do codigo da venda do produto
int buscaVendaP(FILE *Ptrvp, int codVenda)
{
	TpVendaProd venda;
	rewind(Ptrvp);
	fread(&venda,sizeof(TpVendaProd),1,Ptrvp);
	
	while(!feof(Ptrvp) && !(codVenda == venda.codVenda && venda.status == 'A'))
		fread(&venda,sizeof(TpVendaProd),1,Ptrvp);
		
	if(!feof(Ptrvp) && venda.status == 'A')
		return ftell(Ptrvp) - sizeof(TpVendaProd);
	else
		return -1;
}


//Fun��o que faz relatorio de vendas de produtos em arquivo binario
void relatorioVendas(void)
{
	int pos, i=8, auxCod, auxCpf, posvp, posf, posv;
	TpProdutos prod;
	TpFornecedor forn;
	TpCliente cli;
	TpVendaProd vendaP;
	TpVendas vendas;
	
	FILE *Ptrp = fopen("produto.dat","rb");
	FILE *Ptrf = fopen("fornecedor.dat","rb");
	FILE *Ptrc = fopen("cliente.dat","rb");
	FILE *Ptrvp = fopen("vendaProd.dat","rb");
	FILE *Ptrv = fopen("vendas.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Relatorio De Vendas ***");
	
	if(Ptrp == NULL || Ptrf == NULL || Ptrc == NULL || Ptrvp == NULL || Ptrv == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		fread(&vendas,sizeof(TpVendas),1,Ptrv);
		fread(&vendaP,sizeof(TpVendaProd),1,Ptrvp);
		while(!feof(Ptrv))
		{
			
			gotoxy(30,i);
			printf("Codigo da venda: %d",vendas.codVenda);
			i++;
			gotoxy(30,i);
			printf("COD.");
			gotoxy(37,i);
			printf("DESCR.");
			gotoxy(47,i);
			printf("QTDE.");
			gotoxy(55,i);
			printf("PRECO");
			gotoxy(68,i);
			printf("NOME FORN.");
			i++;
			
			
			while(!feof(Ptrvp))
			{
				pos = buscaProd(Ptrp,vendaP.codProd);
				fseek(Ptrp,pos,SEEK_SET);
				fread(&prod,sizeof(TpProdutos),1,Ptrp);
						
				posf = BuscaForn(Ptrf,prod.codForn);
				fseek(Ptrf,posf,SEEK_SET);
				fread(&forn,sizeof(TpFornecedor),1,Ptrf);
				
				
				auxCod = vendas.codVenda;
				
				if(auxCod == vendaP.codVenda)
				{
					gotoxy(30,i);
					printf("%d",vendaP.codProd);
					gotoxy(37,i);
					printf("%s",prod.descr);
					gotoxy(48,i);
					printf("%d",vendaP.qtde);
					gotoxy(55,i);
					printf("R$%.2f",vendaP.valorUni * vendaP.qtde);
					gotoxy(68,i);
					printf("%s",forn.nomeForn);
					i++;
					
					if(i>=19)
					{
						LimpaMensagem();
						gotoxy(13,23);
						printf("Aperte enter para contiuar mostrando o relatorio");
						getch();
						LimpaTela();
						i=8;
						gotoxy(30,6);
						printf("*** Relatorio de vendas ***");
					}
				}
				if(i>=19)
				{
					LimpaMensagem();
					gotoxy(13,23);
					printf("Aperte enter para contiuar mostrando o relatorio");
					getch();
					LimpaTela();
					i=8;
					gotoxy(30,6);
					printf("*** Relatorio de vendas ***");
				}
				fread(&vendaP,sizeof(TpVendaProd),1,Ptrvp);
			}
			//j� que mudou o codigo da venda, voltamos para a posi��o 0 para procurar
			rewind(Ptrvp);
			fread(&vendaP,sizeof(TpVendaProd),1,Ptrvp);
			
			gotoxy(30,i);
			printf("TOTAL: %.2f",vendas.totVenda);
			i++;
			gotoxy(30,i);
			printf("DATA DA VENDA:");
			gotoxy(45,i);
			printf("%d/%d/%d",vendas.data.dia,vendas.data.mes,vendas.data.ano);
			
			i++;					
			gotoxy(30,i);
			printf("DADOS CLIENTE: ");
			i++;
				
				
				
			auxCpf = vendas.CPFCLI;
			pos = buscaCli(Ptrc,auxCpf);
				
			fseek(Ptrc,pos,SEEK_SET);
			fread(&cli,sizeof(TpCliente),1,Ptrc);
				
			gotoxy(30,i);
			printf("CPF: %d",cli.cpf);
			gotoxy(52,i);
			printf("Nome: %s",cli.nomeCliente);
			i++;
				
			LimpaMensagem();
			gotoxy(13,23);
			printf("Aperte enter para continuar o relatorio!");
			getch();
			LimpaTela();
			i=8;
			gotoxy(30,6);
			printf("*** Relatorio de vendas ***");
			
			fread(&vendas,sizeof(TpVendas),1,Ptrv);
		}
		LimpaMensagem();
		gotoxy(13,23);
		printf("Relatorio finalizado!");
		
		fclose(Ptrp);
		fclose(Ptrc);
		fclose(Ptrf);
		fclose(Ptrv);
		fclose(Ptrvp);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz a venda de produtos em arquivo binario
void Venderprod(void)
{
	int pos, i=10, auxCod, auxCpf, posc, cont=0, posf, posvp;
	char op;
	float tot=0;
	
	TpProdutos prod;
	TpFornecedor forn;
	TpCliente cli;
	TpVendaProd vendaP;
	TpVendas vendas;
	
	FILE *Ptrp = fopen("produto.dat","rb+");
	FILE *Ptrf = fopen("fornecedor.dat","rb");
	FILE *Ptrc = fopen("cliente.dat","rb+");
	FILE *Ptrvp = fopen("vendaProd.dat","ab+");
	FILE *Ptrv = fopen("vendas.dat","ab+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Vendas De Produtos ***");
	
	if(Ptrp == NULL || Ptrf == NULL || Ptrc == NULL || Ptrvp == NULL || Ptrv == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Digite o cpf do cliente: ");
		scanf("%d",&cli.cpf);
		posc = buscaCli(Ptrc,cli.cpf);
		
		fseek(Ptrc,posc,SEEK_SET);
		fread(&cli,sizeof(TpCliente),1,Ptrc);
		
		if(posc >= 0)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("Cpf Valido!");
			getch();
			
			LimpaMensagem();
			gotoxy(13,23);
			printf("Digite 0 para encerrar!");
			gotoxy(30,8);//entra lido
			printf("Codigo do Produto para ser vendido: ");
			scanf("%d",&prod.cod);
			while(prod.cod > 0 )
			{
				
				pos = buscaProd(Ptrp,prod.cod);
				fseek(Ptrp,pos,SEEK_SET);
				fread(&prod,sizeof(TpProdutos),1,Ptrp);
				
				if(prod.cod>0)
				{
					if(pos==-1)
					{	
						LimpaMensagem(); 
						gotoxy(13,23);
						printf("Produto nao cadastrado!");
						getch();
						LimpaTela();
					}
					else
					{
						LimpaTela();
						gotoxy(13,23);
						printf("Produto encontrado!");
						gotoxy(30,7);
						printf("*** Vendas De Produtos ***");
						gotoxy(30,9);
						printf("Preco unitario do produto: %.2f",prod.preco);
						gotoxy(30,10);
						printf("Quantidade atual deste produto: %d",prod.estoque);
						gotoxy(30,11);
						printf("Quantidade que deseja comprar: ");	
						scanf("%d",&vendaP.qtde);
						fseek(Ptrv,0,2);
						cont = ftell(Ptrv)/sizeof(TpVendas);
						
						if(vendaP.qtde<=0)
						{
							LimpaTela();
							gotoxy(13,23);
							printf("Quantidade invalida!");
							getch();
						}
						else
						{
							if(vendaP.qtde>prod.estoque)
							{
								LimpaMensagem();
								gotoxy(13,23);
								printf("Estoque insuficiente!");
								getch();
							}
							else
							{
								vendas.CPFCLI = cli.cpf;
								vendaP.codVenda = cont+1;	
								vendaP.valorUni = prod.preco;
							
								gotoxy(30,13);
								printf("Valor total da venda: %.2f",vendaP.valorUni*vendaP.qtde);
								
								LimpaMensagem();
								gotoxy(13,23);
								printf("Deseja finalizar a venda? (S/N)");
								
								op = toupper(getch());
								if(op == 'S')
								{
									vendaP.status = 'A';
									vendas.status = 'A';
									
									vendaP.codVenda = cont + 1;
									vendaP.codProd = prod.cod;
									prod.estoque = prod.estoque - vendaP.qtde;
									
									
									tot = vendaP.valorUni*vendaP.qtde + tot;
								
									cli.qtdeCompra = vendaP.qtde + cli.qtdeCompra;
									cli.valorTotCompr = tot + cli.valorTotCompr;
									
									//salvando as informa��es do cliente no arquivo cliente
									fseek(Ptrc,posc,SEEK_SET); 
									fwrite(&cli,sizeof(TpCliente),1,Ptrc);
									
									//salvando as informa��es do produto no arquivo produtos
									fseek(Ptrp,pos,SEEK_SET);
									fwrite(&prod,sizeof(TpProdutos),1,Ptrp);
									
									fwrite(&vendaP,sizeof(TpVendaProd),1,Ptrvp);
									
									LimpaMensagem();
									gotoxy(13,23);
									printf("Venda feita com sucesso!");
									getch();
								}
								else
								{
									LimpaMensagem();
									gotoxy(13,23);
									printf("Venda encerrada!");
									getch();
								}	
							}
						}
					}
				}
				else
				{	
					LimpaMensagem(); 
					gotoxy(13,23);
					printf("Venda encerrada!");
					getch();
					LimpaTela();
				}
				
					LimpaTela();
					gotoxy(30,6);
					printf("*** Vender produtos ***");
						
					gotoxy(13,23);
					printf("Digite 0 para encerrar!");
					gotoxy(30,8);//sai lido
					printf("Codigo do Produto para ser vendido: ");
					scanf("%d",&prod.cod);
			}
						
		}
		else
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("Cpf nao encontrado!");
		}
		
		if(ftell(Ptrvp) > 0 && op == 'S')
		{
			LimpaTela();
			gotoxy(30,6);
			printf("*** Vendas De Produtos ***");
				
			gotoxy(30,8);
			printf("Data da venda dd/mm/aa: ");
			scanf("%d",&vendas.data.dia);
			gotoxy(30,9);
			scanf("%d",&vendas.data.mes);
			gotoxy(30,10);
			scanf("%d",&vendas.data.ano);
			
			vendas.codVenda = cont+1;
			vendas.totVenda = tot;
			fwrite(&vendas,sizeof(TpVendas),1,Ptrv);
				
			LimpaMensagem();
			gotoxy(13,23);
			printf("Aperte enter para emitir a nota fiscal!");
			getch();
				
			posvp = buscaVendaP(Ptrvp,vendaP.codVenda);
			fseek(Ptrvp,posvp,SEEK_SET);
			fread(&vendaP,sizeof(TpVendaProd),1,Ptrvp);	
				
			LimpaTela();
			gotoxy(30,6);
			printf("*** Nota Fiscal ***");
			gotoxy(30,8);
			printf("Codigo da venda: %d",vendaP.codVenda);
			gotoxy(30,9);
			printf("DADOS DA VENDA:");
			
			gotoxy(30,i);
			printf("COD.");
			gotoxy(37,i);
			printf("DESCR.");
			gotoxy(47,i);
			printf("QTDE.");
			gotoxy(55,i);
			printf("PRECO");
			gotoxy(68,i);
			printf("NOME FORN.");
			i++;
				
				
			while(!feof(Ptrvp))
			{
				pos = buscaProd(Ptrp,vendaP.codProd);
				fseek(Ptrp,pos,SEEK_SET);
				fread(&prod,sizeof(TpProdutos),1,Ptrp);
					
				posf = BuscaForn(Ptrf,prod.codForn);
				fseek(Ptrf,posf,SEEK_SET);
				fread(&forn,sizeof(TpFornecedor),1,Ptrf);
				
				tot = vendaP.qtde * vendaP.valorUni;
				gotoxy(30,i);
				printf("%d",vendaP.codProd);
				gotoxy(37,i);
				printf("%s",prod.descr);
				gotoxy(48,i);
				printf("%d",vendaP.qtde);
				gotoxy(55,i);
				printf("R$%.2f",tot);
				gotoxy(68,i);
				printf("%s",forn.nomeForn);
				i++;
				if(i>=21)
				{
					LimpaMensagem();
					gotoxy(13,23);
					printf("Pressione enter para contiuar mostrando a nota fiscal");
					getch();
					LimpaTela();
					i=10;
					gotoxy(30,6);
					printf("*** Nota fiscal ***");
					gotoxy(30,8);
					printf("Codigo da venda: %d",vendaP.codVenda);
					gotoxy(30,9);
					printf("DADOS DA VENDA:");
							
					gotoxy(30,i);
					printf("COD.");
					gotoxy(37,i);
					printf("DESCR.");
					gotoxy(47,i);
					printf("QTDE.");
					gotoxy(55,i);
					printf("PRECO");
					gotoxy(68,i);
					printf("NOME FORN.");
					i++;
				}
				fread(&vendaP,sizeof(TpVendaProd),1,Ptrvp);
			}
			if(i>=16)
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Aperte enter para continuar a nota fiscal!");
				getch();
					
				LimpaTela();
				gotoxy(30,6);
				printf("*** Nota Fiscal ***");
				i=8;
			}
			gotoxy(30,i);
			printf("TOTAL: %.2f",vendas.totVenda);
			i++;
			gotoxy(30,i);
			printf("DATA DA VENDA:");
			gotoxy(45,i);
			printf("%d/%d/%d",vendas.data.dia,vendas.data.mes,vendas.data.ano);
				
			i++;					
			gotoxy(30,i);
			printf("DADOS CLIENTE: ");
			i++;
			gotoxy(30,i);
			printf("CPF: %d",cli.cpf);
			gotoxy(52,i);
			printf("Nome: %s",cli.nomeCliente);
				
			LimpaMensagem();
			gotoxy(13,23);
			printf("Nota fiscal emitida!");
		}
		
		cont++;
		
		fclose(Ptrp);
		fclose(Ptrc);
		fclose(Ptrf);
		fclose(Ptrv);
		fclose(Ptrvp);
	}
	getch();
	LimpaTela();
}

//Main onde o c�digo vai come�ar
int main(void)
{
	//Declarando a struct de produto
	TpProdutos prod;
	
	//Declarando a struct de clientes
	TpCliente cliente;
	
	//Declarando a struct de fornecedor
	TpFornecedor forn;
	
	//Declarando a struct de vendas
	TpVendas vender;
	
	//Declarando a struct de vendas prod
	TpVendaProd vendas;
	
	int tlp=0, tlc=0, tlf=0, tlv=0, tlvp=0, p=0;
	char op;
	
	Formulario();
	
	do
	{
		//Repeti�Cpf queigue o usario a digitar uma das op��es
		op = tolower(getch());
		while(op != 'p' && op != 'c' && op != 'f' && op != 27)
			op = tolower(getch());
		switch(op)
		{
			case 'p':
				//Repeti��o para que obrigue o usario a digitar uma das op��es
				op = menuProd();
				while(op != 'A' && op != 'B' && op != 'C' && op != 'D' && op != 'E' && op != 'F' && op != 'G' && op != 'H' && op != 'I' && op != 'J' && op != 48)
			        op = toupper(getch()); 
				switch(op)
				{
					case 'A':
						cadProd();
						                                               
						break;
					
					case 'B':
						ConsultaProd();         
						
						break;
						
					case 'C':
						excProd(); 
						
						break;
						
					case 'D':
						alteraProd();
						
						break;
						
					case 'E':
						relatorioProd();
						
						break;
						
					case 'F':
						relatorioVendas();
						
						break;
						
					case 'G':
						Venderprod();
						
						break;
					/*
					case 'I':
						excluiVenda();
						
						break;
					*/
					case 48:
						LimpaTela();
						gotoxy(38,10);
						printf("*** Selecione a opcao desejada ***");
						getch();
					
						break;
				}
				break;
			case 'c':
				
				//Repeti��o para que obrigue o usario a digitar uma das op��es
				op = menuCliente();
				while(op != 'A' && op != 'B' && op != 'C' && op != 'D' && op != 'E' && op != 'F' && op != 48)
					op = toupper(getch());
				switch(op)
				{
					case 'A':
						cadCliente(); 
						
						break;
						
					case 'B':
						ConsultaCliente();  
						
						break;
						
					case 'C':
						excCliente();
						
						break;
					
					case 'D':
						alteraCliente();
						
						break;
					
					
					case 'E':
						relatorioCliente();
						
						break;
						
						
					case 48:
						LimpaTela();
						gotoxy(38,10);
						printf("*** Selecione a opcao desejada ***");
						getch();
					
						break;
				}	
				break;
				
			case 'f':
				//Repeti��o para que obrigue o usario a digitar uma das op��es
				op = menuForn();
				while(op != 'A' && op != 'B' && op != 'C' && op != 'D' && op != 'E' && op !='F' && op != 'G' && op != 48)
					op = toupper(getch());
				switch(op)
				{
					case 'A':
						cadForn(); 
						
						break;
						
					case 'B':
						consultaForn();
						
						break;
						
					case 'C':
						excForn();
						
						break;
						
					case 'D':
						alteraForn();
						
						break;
					
					case 'E':
						aumentaForn();
						
						break;
						
					case 'F':
						relatorioForn();
						
						break;
						
					case 48:
						LimpaTela();
						gotoxy(38,10);
						printf("*** Selecione a opcao desejada ***");
						getch();
						
						break;
				}
				break;
				
			//Mensagem para quando o usario quiser sair do programa
			case 27:
				gotoxy(13,23);
				printf("Programa encerrado!");
				getch();
				break;
	
		}
	}while(op!=27);
	
	
	return 0;
}

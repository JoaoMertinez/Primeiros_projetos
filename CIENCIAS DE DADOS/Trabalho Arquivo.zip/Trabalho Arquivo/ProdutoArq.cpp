#include<stdio.h>
#include<conio2.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

/*"rb" Abrir um arquivo bin�rio para leitura. O arquivo deve estar presente no disco.

"wb" Abrir um arquivo bin�rio para grava��o. Se o arquivo estiver presente ele ser� 
destru�do e reinicializado. Se n�o existir, ele ser� criado.

"ab" Abrir um arquivo bin�rio para inclus�o. Os dados ser�o adicionados ao fim do arquivo 
existente, ou um novo arquivo ser� criado. N�o permite leitura dos dados.

"rb+" Abrir um arquivo bin�rio para leitura e grava��o. O arquivo deve existir e pode ser 
atualizado.

"wb+" Abrir um arquivo bin�rio para leitura e grava��o. Se o arquivo existir ele ser� 
destru�do e reinicializado. Se n�o existir, ser� criado.

"ab+" Abrir um arquivo bin�rio para atualiza��es e para adicionar dados ao fim do arquivo 
existente ou um novo arquivo ser� criado. Possibilita a leitura dos dados existentes.*/


//Struct com as datas de validade
struct TpValidade
{
	int dia, mes, ano;
};

//Struct com as datas de venda
struct TpData
{
	int dia, mes, ano;
};

//Struct com as informa��es dos produtos
struct TpProdutos
{
	int cod, estoque, codForn;
	char descr[30], status;
	float preco;
	
	TpValidade validade;
};

//Struct com as informa��es dos fornecedores
struct TpFornecedor
{
	int codForn;
	char nomeForn[30], cidade[30],status;
};

//Struct com as informa��es dos clientes
struct TpCliente
{
	int qtdeCompra, cpf;
	char nomeCliente[30], status;
	float valorTotCompr;
	TpData data;
};

//Struct com as informa��es das vendas
struct TpVendas
{
	int codVenda; //CodVenda tem que ser sequencial
	float totVenda;
	char CPFCLI[11];
	TpData data;
	
};

//Struct com as informa��es das vendas dos produtos
struct TpVendaProd
{
	int codProd;
	int codVenda;
	int qtde;
	float valorUni;
};

//Fun��o que limpa a tela
void LimpaTela(void)
{
	 int x,y;
	 //LIMPA QUADRADO
	 for(x=30;x<=78;x++)
	 {
		for(y=6;y<=20;y++)
		{
		   gotoxy(x,y);
		   printf(" ");
		}
	 }
	 //LIMPA MENSAGEM
	 for(x=13;x<78;x++)
	 {
	 	gotoxy(x,23);
		printf("  ");
	 }
}

//Fun��o que Limpa Mensagem
void LimpaMensagem(void)
{
	int x,y;
	
	for(x=13;x<78;x++)
	 {
	 	gotoxy(x,23);
		printf("  ");
	 }
}


void moldura(int CI, int LI, int CF, int LF, int CorT, int CorF)
{
	int i;
	textcolor(12);
	textbackground(3);
	gotoxy(CI,LI);
	printf("%c",201);
	gotoxy(CI,LF);
	printf("%c",200);
	gotoxy(CF,LI);
	printf("%c",187);
	gotoxy(CF,LF);
	printf("%c",188);
	for(i=CI+1; i<CF; i++)
	{
		gotoxy(i,LI); printf("%c",205);
		gotoxy(i,LF); printf("%c",205);
	}
	for(i=LI+1; i<LF; i++)
	{
		gotoxy(CI,i); printf("%c",186);
		gotoxy(CF,i); printf("%c",186);
	}
	
	textcolor(7);
	textbackground(0);
}

//Fun��o com o menu principal
void menuPrincipal(void)
{
	textcolor(15);
	gotoxy(3,7);
	printf("# #  M E N U  # #");
	gotoxy(3,9);
	printf("[P] Produtos");
	gotoxy(3,10);
	printf("[C] Clientes");
	gotoxy(3,11);
	printf("[F] Fornecedores");
	gotoxy(3,19);
	printf("[ESC] Sair");
}

//Fun��o que passa os valores da moldura
void Formulario(void)
{
	system("cls");
	moldura(1,1,80,25,10,5);
	gotoxy(27,3);
	textcolor(15);
	printf(" # # #  MERCADO DO LUDIMILO  # # #");
	
	moldura(2,2,79,4,14,1);
	moldura(2,5,27,21,12,7);
	menuPrincipal();
	moldura(2,22,79,24,11,4);
	gotoxy(4,23);
	textcolor(12);
	printf("Mensagem: ");

	moldura(28,5,79,21,9,6);
}

//Fun��o do menu de op��o para o usuario escolher (PRODUTOS)
char menuProd(void)
{
	LimpaTela();
	gotoxy(30,6);
	printf("# # #  M E N U  P R O D U T O S  # # #\n");
	gotoxy(30,8);
	printf("[A] Cadastrar Produtos");
	gotoxy(30,9);
	printf("[B] Consultar Produtos");
	gotoxy(30,10);
	printf("[C] Excluir Produtos");
	gotoxy(30,11);
	printf("[D] Alteracao de Dados");
	gotoxy(30,12);
	printf("[E] Relatorio de Produtos");
	gotoxy(30,13);
	printf("[F] Relatorio de vendas");
	gotoxy(30,14);
	printf("[G] Vender Produtos");
	gotoxy(30,15);
	printf("[H] Insercao de estoque");
	gotoxy(30,16);
	printf("[I] Exclusao de Vendas");
	gotoxy(30,17);
	printf("[0] Sair\n");
	gotoxy(30,19);
	printf("Opcao desejada: ");
	return toupper(getch());
}

//Fun��o do menu de op��o para o usuario escolher (CLIENTES)
char menuCliente(void)
{
	LimpaTela();
	gotoxy(30,6);
	printf("# # #  M E N U  C L I E N T E S  # # #\n");
	gotoxy(30,8);
	printf("[A] Cadastrar Cliente");
	gotoxy(30,9);
	printf("[B] Consultar Cliente pelo cpf");
	gotoxy(30,10);
	printf("[C] Excluir cliente");
	gotoxy(30,11);
	printf("[D] Alteracao de Dados");
	gotoxy(30,12);
	printf("[E] Relatorio de clientes");
	gotoxy(30,13);
	printf("[0] Sair\n");
	gotoxy(30,15);
	printf("Opcao desejada: ");
	return toupper(getche());
}

//Fun�ao do menu de fornecedor
char menuForn(void)
{
	LimpaTela();
	gotoxy(30,6);
	printf("# # #  M E N U  F O R N E C E D O R  # # #\n");
	gotoxy(30,8);
	printf("[A] Cadastrar novo fornecedor");
	gotoxy(30,9);
	printf("[B] Consultar Fornecedores");
	gotoxy(30,10);
	printf("[C] Excluir fornecedores");
	gotoxy(30,11);
	printf("[D] Alteracao de Dados");
	gotoxy(30,12);
	printf("[E] Aumento de preco por fornecedor");
	gotoxy(30,13);
	printf("[F] Relatorio de dados");
	gotoxy(30,14);
	printf("[0] Sair\n");
	gotoxy(30,16);
	printf("Opcao desejada: ");
	return toupper(getche());
	
}

//Fun��o que faz a busca do c�digo do fornecedor em arquivo
int BuscaForn(FILE *ptr, int cod)
{
	TpFornecedor forn;
	rewind(ptr);
	fread(&forn,sizeof(TpFornecedor),1,ptr);
	
	while(!feof(ptr) && !(cod == forn.codForn && forn.status == 'A'))
		fread(&forn,sizeof(TpFornecedor),1,ptr);
	
	if(!feof(ptr) && forn.status == 'A')
		return ftell(ptr)-sizeof(TpFornecedor);
	else
		return -1;	
}

//Fun��o que faz a busca pelo codigo do produto
int buscaProd(FILE *Ptr, int cod)
{
	TpProdutos prod;
	rewind(Ptr);
	fread(&prod,sizeof(TpProdutos),1,Ptr);
	
	while(!feof(Ptr) && cod != prod.cod)
		fread(&prod,sizeof(TpProdutos),1,Ptr);
		
	if(!feof(Ptr) && prod.status != 'A')
		return ftell(Ptr) - sizeof(TpProdutos);
	else
		return -1;
}

//Fun��o que faz cadastro de produtos em arquivo binario
void cadProd(void)
{
	int pos,pos2;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","ab+");
	FILE *Ptrf = fopen("fornecedor.dat","rb");//tem que abrir o arquivo de fornecedor pra fazer a busca
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Cadastro De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo do produto: ");
		scanf("%d",&prod.cod);
		
		while(prod.cod != 0)
		{
			pos = buscaProd(Ptr,prod.cod);
			
			if(pos == -1)
			{	
				gotoxy(30,9);
				printf("Descricao do Produto: ");
				fflush(stdin);
				gets(prod.descr);
				gotoxy(30,10);
				printf("Quantidade em Estoque: ");
				scanf("%d",&prod.estoque);
				gotoxy(30,11);
				printf("Preco: ");
				scanf("%f",&prod.preco);
				gotoxy(30,12);
				printf("Data de Validade dd/mm/aa: ");
				scanf("%d",&prod.validade.dia);
				gotoxy(30,13);
				scanf("%d",&prod.validade.mes);
				gotoxy(30,14);
				scanf("%d",&prod.validade.ano);
				gotoxy(30,15);
				printf("Digite o codigo do fornecedor");
				scanf("%d",&prod.codForn);
				prod.status = 'A';
				pos2 = BuscaForn(Ptr,prod.codForn);
				if(pos2 == -1)
				{
					LimpaTela();
					gotoxy(13,23);
					printf("Fornecedor nao encontrado");
					/*slepy(5);*/
					//cadFor(TabForn,tlf);
				}
				else
				{
					fseek(Ptr,pos,0);
					fwrite(&prod,sizeof(TpProdutos),1,Ptr);	
					
				}				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Produto cadastrado com sucesso!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Produto j� cadastrado!");
			}
			getch();
			LimpaTela();
			gotoxy(30,6);
			printf("*** Cadastro De Produtos ***");
			gotoxy(30,8);
			printf("Digite o codigo do produto: ");
			scanf("%d",&prod.cod);
		}
		fclose(Ptr);
		fclose(Ptrf);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz consulta de produtos em arquivo binario
void ConsultaProd(void)
{
	int pos;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Consulta De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Digite o codigo do produto: ");
		scanf("%d",&prod.cod);
		
		pos = buscaProd(Ptr,prod.cod);
		
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("O produto nao foi encontrado!");
		}
		else
		{
			fseek(Ptr,pos,SEEK_SET);
			fread(&prod,sizeof(TpProdutos),1,Ptr);
			if(prod.status == 'A')
			{
				gotoxy(30,10);
				printf("*** DADOS DO PRODUTO ***");	
			
				gotoxy(30,11);
				printf("Codigo produto: %d",prod.cod);
				gotoxy(30,12);
				printf("Codigo fornecedor: %d",prod.codForn);
				gotoxy(30,23);
				printf("Descricao: %s",prod.descr);
				gotoxy(30,14);
				printf("Estoque: %d",prod.estoque);
				gotoxy(30,15);
				printf("Preco: %.2f",prod.preco);
				gotoxy(30,16);
				printf("Validade: %d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Consulta finalizada!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("O produto nao foi encontrado!");
			}
			
		}
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz exclus�o logica do arquivo de produtos
void excProd(void)
{
	int pos;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Exclusao Logica De Produto ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo do produto: ");
		scanf("%d",&prod.cod);
		
		pos = buscaProd(Ptr,prod.cod);
		
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("O produto nao foi encontrado!");
		}
		else
		{	
			gotoxy(30,10);
			printf("*** DADOS DO PRODUTO ***");	
			
			fseek(Ptr,pos,SEEK_SET);
			fread(&prod,sizeof(TpProdutos),1,Ptr);
			gotoxy(30,11);
			printf("Codigo produto: %d",prod.cod);
			gotoxy(30,12);
			printf("Codigo fornecedor: %d",prod.codForn);
			gotoxy(30,13);
			printf("Descricao: %s",prod.descr);
			gotoxy(30,14);
			printf("Estoque: %d",prod.estoque);
			gotoxy(30,15);
			printf("Preco: %.2f",prod.preco);
			gotoxy(30,16);
			printf("Validade: %d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
			
			LimpaMensagem();
			gotoxy(13,23);
			printf("Deseja finalizar a exlusao?(S/N) ");
			
			if(toupper(getch()) == 'S')
			{
				prod.status = 'I';
				
				fseek(Ptr,pos,SEEK_SET);
				fwrite(&prod,sizeof(TpProdutos),1,Ptr);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Exlusao logica finalizada!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Voce nao autorizou a exclusao!");
			}
			
		}
		
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Fun��o que faz altera��o de produtos em arquivo binario
void alteraProd(void)
{
	int pos;
	TpProdutos prod;
	FILE *Ptr = fopen("produto.dat","rb+");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Alteracao De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		gotoxy(30,8);
		printf("Codigo do produto: ");
		scanf("%d",&prod.cod);
		
		pos = buscaProd(Ptr,prod.cod);
		
		if(pos == -1)
		{
			LimpaMensagem();
			gotoxy(13,23);
			printf("O produto nao foi encontrado!");
		}
		else
		{
			gotoxy(30,10);
			printf("*** DADOS DO PRODUTO ***");	
			
			fseek(Ptr,pos,SEEK_SET);
			fread(&prod,sizeof(TpProdutos),1,Ptr);
			gotoxy(30,11);
			printf("Codigo produto: %d",prod.cod);
			gotoxy(30,12);
			printf("Codigo fornecedor: %d",prod.codForn);
			gotoxy(30,13);
			printf("Descricao: %s",prod.descr);
			gotoxy(30,14);
			printf("Estoque: %d",prod.estoque);
			gotoxy(30,15);
			printf("Preco: %.2f",prod.preco);
			gotoxy(30,16);
			printf("Validade: %d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
			
			LimpaMensagem();
			gotoxy(13,23);
			printf("Deseja finalizar a alteracao?(S/N) ");
			
			if(toupper(getch()) == 'S')
			{
				LimpaMensagem();
				gotoxy(30,6);
				printf("*** Alteracao De Produtos ***");
				
				gotoxy(30,8);
				printf("Nova descricao: ");
				fflush(stdin);
				gets(prod.descr);
				gotoxy(30,9);
				printf("Novo estoque: ");
				scanf("%d",&prod.estoque);
				gotoxy(30,10);
				printf("Novo preco: ");
				scanf("%f",&prod.preco);
				gotoxy(30,11);
				printf("Nova validade: ");
				scanf("%d",&prod.validade.dia);
				gotoxy(30,12);
				scanf("%d",&prod.validade.mes);
				gotoxy(30,13);
				scanf("%d",&prod.validade.ano);
				
				fseek(Ptr,pos,SEEK_SET);
				fwrite(&prod,sizeof(TpProdutos),1,Ptr);
				
				LimpaMensagem();
				gotoxy(13,23);
				printf("Alteracao de produto feita com sucesso!");
			}
			else
			{
				LimpaMensagem();
				gotoxy(13,23);
				printf("Voce nao autorizou a alteracao de dados!");
			}
		}
		fclose(Ptr);
	}
	getch();
	LimpaMensagem();
}

//Fun��o que faz relatorio de produtos em arquivo binario
void relatorioProd(void)
{
	int i=9;
	TpProdutos prod;
	FILE *Ptr = fopen ("produto.dat","rb");
	
	LimpaTela();
	gotoxy(30,6);
	printf("*** Relatorio De Produtos ***");
	
	if(Ptr == NULL)
	{
		gotoxy(13,23);
		printf("Erro na abertura do arquivo!");
	}
	else
	{
		fread(&prod,sizeof(TpProdutos),1,Ptr);
		while(!feof(Ptr))
		{
			if(!feof(Ptr) && prod.status == 'A')
			{
				
				gotoxy(30,8);
				printf("COD.");
				gotoxy(30,i);
				printf("%d",prod.cod);
				gotoxy(38,8);
				printf("DESCR.");
				gotoxy(38,i);
				puts(prod.descr);
				gotoxy(48,8);
				printf("ETQ.");
				gotoxy(48,i);
				printf("%d",prod.estoque);
				gotoxy(56,8);
				printf("PRECO");
				gotoxy(56,i);
				printf("%.2f",prod.preco);
				gotoxy(65,8);
				printf("VALIDADE");
				gotoxy(65,i);
				printf("%d/%d/%d",prod.validade.dia,prod.validade.mes,prod.validade.ano);
				
				i = i + 2;
				
				if(i>=20)
				{
					LimpaMensagem();
					gotoxy(13,23);
					printf("Aperte enter para aparecer o restante do relatorio");
					getch();
					LimpaTela();
					gotoxy(30,6);
					printf("*** Relatorio De Produtos ***");
					i=9;
				}
				
				fread(&prod,sizeof(TpProdutos),1,Ptr);
			}
		}
		LimpaMensagem();
		gotoxy(13,23);
		printf("Relatorio finalizado!");
		
		fclose(Ptr);
	}
	getch();
	LimpaTela();
}

//Main onde o c�digo vai come�ar
int main(void)
{
	//Declarando a struct de produto
	TpProdutos prod;
	
	//Declarando a struct de clientes
	TpCliente cliente;
	
	//Declarando a struct de fornecedor
	TpFornecedor forn;
	
	//Declarando a struct de vendas
	TpVendas vender;
	
	//Declarando a struct de vendas prod
	TpVendaProd vendas;
	
	char op;
	
	Formulario();
	
	do
	{
		//Repeti�Cpf queigue o usario a digitar uma das op��es
		op = tolower(getch());
		while(op != 'p' && op != 'c' && op != 'f' && op != 27)
			op = tolower(getch());
		switch(op)
		{
			case 'p':
				//Repeti��o para que obrigue o usario a digitar uma das op��es
				op = menuProd();
				while(op != 'A' && op != 'B' && op != 'C' && op != 'D' && op != 'E' && op != 'F' && op != 'G' && op != 'H' && op != 'I' && op != 'J' && op != 48)
					op = toupper(getch());         
				switch(op)
				{
				
					case 'A':
						cadProd();
						                                                
						break;
					
					case 'B':
						ConsultaProd();     
						
						break;
						
					case 'C':
						excProd(); 
						
						break;
						
					case 'D':
						alteraProd();
						
						break;
						
					case 'E':
						relatorioProd();
						
						break;
					/*	
					case 'F':
						relatorioVendas();
						
						break;
						
					case 'G':
						Venderprod();
						
						break;
						
					case 'H':
						insercaoProd();
						
						break;
					
					case 'I':
						excluiVenda();
						
						break;
					*/
					case 48:
						LimpaTela();
						gotoxy(38,10);
						printf("*** Selecione a opcao desejada ***");
						getch();
					
						break;
				}
				break;
				/*
			case 'c':
				
				//Repeti��o para que obrigue o usario a digitar uma das op��es
				op = menuCliente();
				while(op != 'A' && op != 'B' && op != 'C' && op != 'D' && op != 'E' && op != 'F' && op != 48)
					op = toupper(getch());
				switch(op)
				{	
					case 'A':
						cadCliente(); 
						
						break;
						
					case 'B':
						ConsultaCliente();  
						
						break;
						
					case 'C':
						excCliente();
						
						break;
					
					case 'D':
						alteraCliente();
						
						break;
					
					
					case 'E':
						relatorioCliente();
						
						break;
						
						
					case 48:
						LimpaTela();
						gotoxy(38,10);
						printf("*** Selecione a opcao desejada ***");
						getch();
					
						break;
				}	
				break;
				
			case 'f':
				//Repeti��o para que obrigue o usario a digitar uma das op��es
				op = menuForn();
				while(op != 'A' && op != 'B' && op != 'C' && op != 'D' && op != 'E' && op !='F' && op != 'G' && op != 48)
					op = toupper(getch());
				switch(op)
				{
					case 'A':
						cadForn(); 
						
						break;
						
					case 'B':
						consultaForn();
						
						break;
						
					case 'C':
						excForn();
						
						break;
						
					case 'D':
						alteraForn();
						
						break;
					
					case 'E':
						aumentaForn();
						
						break;
						
					case 'F':
						relatorioForn();
						
						break;
						
					case 48:
						LimpaTela();
						gotoxy(38,10);
						printf("*** Selecione a opcao desejada ***");
						getch();
						
						break;
				}
				break;
				*/
			//Mensagem para quando o usario quiser sair do programa
			case 27:
				gotoxy(13,23);
				printf("Programa encerrado!");
				getch();
				break;
	
		}
	}while(op!=27);
	
	
	return 0;
}
